#ifndef SUM_H
# define SUM_H
#include "sum.c"
int		sum(int a, int b);
#endif