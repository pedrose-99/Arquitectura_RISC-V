#include "sum.h"

int	sum(int a, int b)
{
	int c = 0;
	c = a + b;
	return c;
}