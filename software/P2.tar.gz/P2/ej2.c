#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[])
{
	int i = 1; 
	char *cad;
	while (i <= (argc -1))
	{
		//strcat()
	}

}