 B-
1. mkdir /tmp/directorio1
2. touch /tmp/directorio1/fichero1 |  touch /tmp/directorio1/fichero2 | touch /tmp/directorio1/fichero3
3. echo "hola mundo" > fichero1 echo "hola mundo" > fichero2 echo "hola mundo" > fichero3
4. echo "cruel" >> fichero2 
