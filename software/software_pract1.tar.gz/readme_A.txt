A-
1. Comando: mkdir /tmp
2. cat > f
hola
^C
3.mv f /tmp/file
4. mv name name2
5. rm -rf d
6. touch empty chmod 544 empty ( 4 read, 2 write, 1 exec, 0 no perm)
7. date -r /tmp
8. pwd en home
