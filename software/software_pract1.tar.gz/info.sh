#!/bin/bash

if [ $# -ne 0 ]
then
	echo " Usage: $0 no arguments required"
	exit 1
else
	hostname

	pwd
	date
	echo *******************
	echo Variables de entorno:

	echo *******************
	echo Ficheros en mi cuenta
	cd
	ls -p | grep -v /
	echo *******************
	echo Directorios en mi cuenta
	cd
	ls -d */

fi
exit 0