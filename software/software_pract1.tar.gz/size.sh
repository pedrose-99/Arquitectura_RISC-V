#!/bin/bash

if [ $# -ne 0 ]
then
	num=1
		while [ $num -le $# ]
		do
			echo Fichero $1
			echo Tamañno $1
			du -s $1
			echo Contenido $1
			cat $1
			echo ""
			echo "******************"
			num=$(($num+1))
		done
else
	echo Usage: $0 arguments required 

fi