#!/bin/bash

if [ $# -ne 0 ]
then
	echo Usage: $0 host.txt
else
	wget -O /tmp/host.txt "https://labs.etsit.urjc.es/fingerprints.txt"

fi